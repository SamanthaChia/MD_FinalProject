export default class TrailerTeaser {
    constructor({ key, name, type }) {
        this.key = key;
        this.name = name;
        this.type = type;
    }
}