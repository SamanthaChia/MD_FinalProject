export default class Cast {
    constructor({ name, id, profile_path }) {
        this.name = name;
        this.id = id;
        this.profile_path = profile_path;
    }
}